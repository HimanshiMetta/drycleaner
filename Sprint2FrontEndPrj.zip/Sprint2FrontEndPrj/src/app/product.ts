export class Product {
    productId!:number;
    category!:string;
    description!:string;
    quantity!:number;
    material!:string;
    price!:number;
}
