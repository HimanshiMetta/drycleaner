export class Cart {
   cartId!: number;
   total!: number;
   //join cart to list of products
}
