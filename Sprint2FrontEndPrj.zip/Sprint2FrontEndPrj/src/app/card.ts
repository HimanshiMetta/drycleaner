export class Card {
    cardId!: number;
    bankName!:string;
    cardNumber!:string;
    expiryDate!:string;
    cvv!:string;
}
