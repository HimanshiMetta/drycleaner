export class User {
    id!: number;
    name!: string;  
    password!: string;
    contactNo!: string;
    emailId!: string;
    address!: string;
}
