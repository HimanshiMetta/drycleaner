import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Card } from 'src/app/card';
import { ListProductServiceService } from 'src/app/list-product-service.service';

@Component({
  selector: 'app-addcard',
  templateUrl: './addcard.component.html',
  styleUrls: ['./addcard.component.css']
})
export class AddcardComponent implements OnInit {

  @Input()
  card!:Card;

  constructor(private listAllService: ListProductServiceService,
    private router: Router) { }
    currentDate=new Date();
  ngOnInit(): void {
  }

  addCard() {
    this.listAllService.addCard(this.card).subscribe(
      (card) => {
        this.router.navigate(['payment']);
      }
    );
  }
}