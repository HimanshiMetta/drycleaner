import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Card } from '../card';
import { ListProductServiceService } from '../list-product-service.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  selectedCard!: Card;
  action!: string;

  constructor(private listAllService: ListProductServiceService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(
      (params) => {
        this.action = params['action']
      }
    );
  }

  addCard() {
    this.selectedCard = new Card();
    this.router.navigate(['payment'], { queryParams: { action: 'add' } });
  }
}
