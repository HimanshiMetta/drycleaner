import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from './product';
import { User } from './user';
import { Card } from './card';

@Injectable({
  providedIn: 'root'
})
export class ListProductServiceService {
  productUrl!:string;
  userUrl!:string;
  constructor(private http:HttpClient) { 
    this.productUrl="http://localhost:8086/product";
    this.userUrl = "http://localhost:8086/users";
  }

  public save(product : Product) {
    return this.http.post<Product>(this.productUrl+"/add", product);
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.productUrl}/delete/${id}`, {responseType: 'text'});
  }

  updateProduct(id: any, data: any): Observable<any> {
    return this.http.put(`${this.productUrl}/update/${id}`, data);
  }

  getProduct(id: number): Observable<any> {
    return this.http.get(`${this.productUrl}/id/${id}`);
  }

  getAllProducts():Observable<Product[]>{
    return this.http.get<Product[]>(this.productUrl+"/all");
  }

  //add user
  addUser(newUser: User) {
    alert("Login Successful, now proceed to add items to your cart!!");
    return this.http.post<User>('http://localhost:8086/users/add', newUser);   
  }

  //add card
  addCard(newCard: Card) {
    alert("Card verified!! proceed to checkout to confirm order.");
    return this.http.post<Card>('http://localhost:8086/card/add', newCard);   
  }

  getProductsByLowToHigh():Observable<Product[]>{
    return this.http.get<Product[]>(this.productUrl+"/low");
  }

  getProductsByHighToLow():Observable<Product[]>{
    return this.http.get<Product[]>(this.productUrl+"/high");
  }
}