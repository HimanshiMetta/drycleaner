import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.cartDetails();
    this.loadCart();
  }

  getCartDetails:any=[];
  cartDetails(){
    if(localStorage.getItem('localCart')){
      this.getCartDetails=JSON.parse(localStorage.getItem('localCart')|| '{}');
     console.log(this.getCartDetails);
    }
  }

  total:number=0;
  loadCart(){
    if(localStorage.getItem('local cart')||'{}'){
      this.getCartDetails=JSON.parse(localStorage.getItem('localCart')||'{}');
      this.total=this.getCartDetails.reduce(function(acc: any,val: any){
          return acc+ val.mrp;
      },0)
    }
  }

  removeall(){
    localStorage.removeItem('localCart');
    this.getCartDetails=[];
    this.total=0;
  }

  remove(cart:any){
    if(localStorage.getItem('localCart')){
      this.getCartDetails=JSON.parse(localStorage.getItem('localCart')||'{}');
      for(let i=0;i<this.getCartDetails.length;i++){
         if(this.getCartDetails[i].productId===cart.productId){
           this.getCartDetails.splice(i,1);
           localStorage.setItem('localCart',JSON.stringify(this.getCartDetails));
           this.loadCart();
          }
      }
    }
  }

  checkout(){
    this.getCartDetails=JSON.parse(localStorage.getItem('localCart')||'{}');
    console.log(this.getCartDetails);
  }

}