import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { ListProductServiceService } from './list-product-service.service';
import { ListProductsComponent } from './list-products/list-products.component';
import { ProductFormComponent } from './product-form/product-form.component';
import { UpdateProductFormComponent } from './update-product-form/update-product-form.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { AdduserComponent } from './login/adduser/adduser.component';
import { CartComponent } from './cart/cart.component';
import { PaymentComponent } from './payment/payment.component';
import { AddcardComponent } from './payment/addcard/addcard.component';
import { AboutComponent } from './about/about.component';
import { ProcessingComponent } from './processing/processing.component';

@NgModule({
  declarations: [
    AppComponent,
    CartComponent,
    ListProductsComponent,
    ProductFormComponent,
    UpdateProductFormComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    AdduserComponent,
    PaymentComponent,
    AddcardComponent,
    AboutComponent,
    ProcessingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    Ng2SearchPipeModule,
    ReactiveFormsModule
  ],
  providers: [ListProductServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
