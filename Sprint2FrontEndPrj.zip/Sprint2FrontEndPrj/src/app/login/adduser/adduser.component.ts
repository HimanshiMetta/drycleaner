import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ListProductServiceService } from 'src/app/list-product-service.service';
import { User } from 'src/app/user';

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {

  @Input()
  user!: User

  constructor(private listAllService: ListProductServiceService,
    private router: Router) { }

  ngOnInit(): void {
  }

  addUser() {
    this.listAllService.addUser(this.user).subscribe(
      (user) => {
        this.router.navigate(['login']);
      }
    );
  }

}