import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ListProductServiceService } from '../list-product-service.service';
import { Product } from '../product';

@Component({
  selector: 'app-list-products',
  templateUrl: './list-products.component.html',
  styleUrls: ['./list-products.component.css']
})
export class ListProductsComponent implements OnInit {

  pdata:Product[]=[];
  searchedKeyword!: string;
  amount!:number;
  pieces!:number;
  
  @Input()
  product!: Product;

  @Output()
  productDeletedEvent = new EventEmitter();

  constructor(private pService:ListProductServiceService) { }

  ngOnInit(): void {
    this.getAllProducts();
    this.amount = 0;
    this.pieces = 0;
  }

  deleteProduct(id: number) {
    if (confirm("Do you want to delete this product?") == true){
      this.pService.deleteProduct(id).subscribe(
        pdata => {
          this.getAllProducts();
        }
      )
    }
  }

  // getAllProducts(){
  //   this.pService.getAllProducts().subscribe(pdata=>this.pdata=pdata);
  // }

  getProductsByLowToHigh(){
    this.pService.getProductsByLowToHigh().subscribe(pdata=>this.pdata=pdata);
  }

  getProductsByHighToLow(){
    this.pService.getProductsByHighToLow().subscribe(pdata=>this.pdata=pdata);
  }

  getAllProducts(){
    this.pService.getAllProducts().subscribe(pdata=>{
      this.pdata=pdata;
      for(let i in pdata)
      {
        this.amount += pdata[i].price;
        this.pieces += pdata[i].quantity;
      }
      console.log(this.amount);
    });
  }

  calculateTotal(price : number){
    this.amount = this.amount + price;
  }

}

